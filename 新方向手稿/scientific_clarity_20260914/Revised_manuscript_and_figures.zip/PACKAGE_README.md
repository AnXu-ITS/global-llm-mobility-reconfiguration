# Current manuscript and figure sources

Snapshot of Overleaf commit `a5a84a226757e7a299ea04df28ab8a6f5d4b1a41`.

The root contains main.tex, supplement.tex, their compiled PDFs, figures, bibliography, figure sources and reproduction records. Use pdfLaTeX to compile main.tex or supplement.tex. Current Figure 2 PDF/SVG/PNG files are in editable_figures/editorial/output/. Main Figures 2–6 use the Python builder in editorial/source; Figure 1 retains PowerPoint. The older seven-slide deck is included only because its S1/S2 sources are still used by the export script.

Historical document ZIPs remain in the local and cloud Overleaf archive and are not duplicated in this download. EDITING_NOTES.md explains the latest changes. E3 horizon checks read the original saved run files and do not launch simulations.
